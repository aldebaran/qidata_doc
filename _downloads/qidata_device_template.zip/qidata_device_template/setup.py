#!/usr/bin/env python2
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os

CONTAINING_DIRECTORY = os.path.dirname(os.path.realpath(__file__))

package_list = find_packages(where=CONTAINING_DIRECTORY)

setup(
    name='package_name',# make sure this is different from any other installed package you might have
    version='0.0.0',
    packages=package_list,
    entry_points={
        'qidata.context.device_models': [
            'Whatever = my_qidata_list.my_list:device_model_list',
            # in the right part, make sure the path to device_model_list fits
            # the actual package tree
        ]
    }
)
