#!/usr/bin/env python2
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os

CONTAINING_DIRECTORY = os.path.dirname(os.path.realpath(__file__))

package_list = find_packages(where=CONTAINING_DIRECTORY)

setup(
    name='qidata_my_custom_annotations',
    version='0.0.1',
    description='Metadata definition',
    packages=package_list,
    install_requires=[
        "strong_typing >= 0.2.3",
        "qidata >= 1.0.1"
    ],
    entry_points={
        'qidata.metadata.definition': [
            'CustomAnnotation = qidata_internal_messages.custom:CustomAnnotation'
            # in the right part, make sure the path to your message fits
            # the actual package tree
            # the left part MUST have the same name as your class
        ]
    }
)
