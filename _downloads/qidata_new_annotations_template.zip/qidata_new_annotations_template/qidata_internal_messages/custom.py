
# Third-party libraries
from qidata.metadata_objects import MetadataObject
from strong_typing.typed_parameters import (IntegerParameter,
                                            EnumParameter,
                                            VectorParameter)

class CustomAnnotation(MetadataObject):

    __ATTRIBUTES__ = [
                       IntegerParameter(name="int",
                                       description="",
                                       default=0),
                       EnumParameter(name="enum",
                                       description="",
                                       choices=["choice1", "choice2"],
                                       default="choice1"),
                       VectorParameter(name="float_vector",
                                       description="",
                                       type=float,
                                       default=[]),
    ]

    __ATT_VERSIONS__ = [None, None, None]

    __VERSION__="0.1"
    __DESCRIPTION__=""
