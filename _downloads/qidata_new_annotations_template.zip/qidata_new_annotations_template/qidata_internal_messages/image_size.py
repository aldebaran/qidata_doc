
# Third-party libraries
from strong_typing import VersionedStruct
from strong_typing.typed_parameters import (IntegerParameter,
                                            EnumParameter,
                                            VectorParameter)

class ImageSize(VersionedStruct):

    __ATTRIBUTES__ = [
                       IntegerParameter(name="height",
                                       description="",
                                       default=0),
                       IntegerParameter(name="width",
                                       description="",
                                       default=0)
    ]

    __ATT_VERSIONS__ = [None, None]

    __VERSION__="0.1"
    __DESCRIPTION__=""
