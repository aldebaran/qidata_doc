# List of known Company device models

device_model_list=[
	"COMPANY_NAME__DEVICE_NAME", # CHANGE THIS
	# ADD OTHER ELEMENTS IF YOU WISH
]
